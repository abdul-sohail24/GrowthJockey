let btn = document.getElementById("price");
let val = btn.value;
function getPrice(event) {
   event.preventDefault();
   btn.innerHTML = val;
}